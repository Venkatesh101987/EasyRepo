﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsoft.Dynamics365.UIAutomation.Api.UCI
{
    public class KeyPerformanceIndicator
    {
        public string Name;
        public double Value;
    }
}
