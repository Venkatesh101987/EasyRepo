﻿namespace Microsoft.Dynamics365.UIAutomation.Api.UCI.DTO
{
    public enum FormContextType
    {
        Entity,
        BusinessProcessFlow,
        QuickCreate,
        Header,
        Dialog
    }
}
