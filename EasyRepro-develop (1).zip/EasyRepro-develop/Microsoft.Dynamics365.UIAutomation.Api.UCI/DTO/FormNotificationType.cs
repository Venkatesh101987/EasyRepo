﻿namespace Microsoft.Dynamics365.UIAutomation.Api.UCI.DTO
{
    public enum FormNotificationType
    {
        Information,
        Warning,
        Error,
        Locked
    }
}
